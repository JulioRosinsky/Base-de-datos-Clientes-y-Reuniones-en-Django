from django.contrib import admin
from .models import *

# Register your models here.
admin.site.register(Videojuego)
admin.site.register(Resena)
admin.site.register(Avatar)
admin.site.register(Tema)
admin.site.register(Comentario)